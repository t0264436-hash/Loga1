"""
Backend API tests for C.G Marketplace (Cardápio Geral)
Tests: auth, stores CRUD, products CRUD, admin permissions, upload
"""
import os
import io
import uuid
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://cg-delivery.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_EMAIL = "admin@cg.com"
ADMIN_PASSWORD = "admin123"


# ---------- Fixtures ----------

@pytest.fixture(scope="session")
def admin_session():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=15)
    assert r.status_code == 200, f"Admin login failed: {r.status_code} {r.text}"
    return s


@pytest.fixture(scope="session")
def lojista_a():
    """Session for lojista A (created here)."""
    s = requests.Session()
    email = f"test_lojistaa_{uuid.uuid4().hex[:8]}@example.com"
    r = s.post(f"{API}/auth/register", json={"email": email, "password": "SecurePass123!", "name": "Lojista A"}, timeout=15)
    assert r.status_code == 200, f"Register lojista A failed: {r.status_code} {r.text}"
    data = r.json()
    return {"session": s, "email": email, "password": "SecurePass123!", "id": data["id"], "name": "Lojista A"}


@pytest.fixture(scope="session")
def lojista_b():
    """Session for lojista B."""
    s = requests.Session()
    email = f"test_lojistab_{uuid.uuid4().hex[:8]}@example.com"
    r = s.post(f"{API}/auth/register", json={"email": email, "password": "SecurePass123!", "name": "Lojista B"}, timeout=15)
    assert r.status_code == 200, f"Register lojista B failed: {r.status_code} {r.text}"
    data = r.json()
    return {"session": s, "email": email, "password": "SecurePass123!", "id": data["id"], "name": "Lojista B"}


# ---------- Auth Tests ----------

class TestAuth:
    def test_register_creates_account_and_returns_cookies(self):
        s = requests.Session()
        email = f"test_reg_{uuid.uuid4().hex[:8]}@example.com"
        r = s.post(f"{API}/auth/register", json={"email": email, "password": "MyPass123!", "name": "Reg User"}, timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["email"] == email
        assert data["name"] == "Reg User"
        assert data["role"] == "lojista"
        assert "id" in data and isinstance(data["id"], str) and len(data["id"]) > 0
        # cookies set
        assert "access_token" in s.cookies, f"access_token cookie missing. Cookies: {dict(s.cookies)}"
        assert "refresh_token" in s.cookies, "refresh_token cookie missing"

    def test_register_duplicate_email_returns_400(self, lojista_a):
        r = requests.post(f"{API}/auth/register",
                          json={"email": lojista_a["email"], "password": "AnotherPass1!", "name": "Dup"},
                          timeout=15)
        assert r.status_code == 400, r.text

    def test_login_correct_returns_user_and_cookies(self, lojista_a):
        s = requests.Session()
        r = s.post(f"{API}/auth/login", json={"email": lojista_a["email"], "password": lojista_a["password"]}, timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["email"] == lojista_a["email"]
        assert data["role"] == "lojista"
        assert "id" in data
        assert "access_token" in s.cookies
        assert "refresh_token" in s.cookies

    def test_login_wrong_password_returns_401(self, lojista_a):
        r = requests.post(f"{API}/auth/login",
                          json={"email": lojista_a["email"], "password": "WrongPassword!"},
                          timeout=15)
        assert r.status_code == 401, r.text

    def test_login_nonexistent_email_returns_401(self):
        r = requests.post(f"{API}/auth/login",
                          json={"email": f"nonexistent_{uuid.uuid4().hex}@example.com", "password": "whatever"},
                          timeout=15)
        assert r.status_code == 401, r.text

    def test_me_with_cookie_returns_user(self, lojista_a):
        r = lojista_a["session"].get(f"{API}/auth/me", timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["email"] == lojista_a["email"]
        assert data["role"] == "lojista"
        assert data["id"] == lojista_a["id"]
        assert "password_hash" not in data

    def test_me_without_cookie_returns_401(self):
        r = requests.get(f"{API}/auth/me", timeout=15)
        assert r.status_code == 401, r.text

    def test_admin_login_returns_admin_role(self):
        s = requests.Session()
        r = s.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=15)
        assert r.status_code == 200, r.text
        assert r.json()["role"] == "admin"


# ---------- Stores Tests ----------

class TestStores:
    def test_create_store_authenticated(self, lojista_a):
        r = lojista_a["session"].post(f"{API}/stores",
                                      json={"name": "TEST_Store_A1", "whatsapp": "+5511987654321"},
                                      timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["name"] == "TEST_Store_A1"
        assert data["whatsapp"] == "+5511987654321"
        assert "id" in data
        assert data["owner_user_id"] == lojista_a["id"]
        lojista_a["store_id"] = data["id"]

    def test_create_store_unauthenticated_returns_401(self):
        r = requests.post(f"{API}/stores", json={"name": "NoAuth", "whatsapp": "+5511"}, timeout=15)
        assert r.status_code == 401, r.text

    def test_list_all_stores_public(self, lojista_a):
        # Ensure at least one store exists
        if "store_id" not in lojista_a:
            self.test_create_store_authenticated(lojista_a)
        r = requests.get(f"{API}/stores", timeout=15)
        assert r.status_code == 200, r.text
        stores = r.json()
        assert isinstance(stores, list)
        assert len(stores) > 0
        # Each store should have id
        assert all("id" in s for s in stores)
        # Should not contain _id (Mongo ObjectId leak)
        assert all("_id" not in s for s in stores), "Stores should not leak Mongo _id"

    def test_get_my_stores_returns_only_own(self, lojista_a, lojista_b):
        # lojista B creates a store
        rb = lojista_b["session"].post(f"{API}/stores",
                                       json={"name": "TEST_Store_B1", "whatsapp": "+5521111"},
                                       timeout=15)
        assert rb.status_code == 200
        lojista_b["store_id"] = rb.json()["id"]

        # lojista A's my stores
        ra = lojista_a["session"].get(f"{API}/stores/my", timeout=15)
        assert ra.status_code == 200, ra.text
        my_a = ra.json()
        assert all(s["owner_user_id"] == lojista_a["id"] for s in my_a)
        # None should belong to B
        ids_a = {s["id"] for s in my_a}
        assert lojista_b["store_id"] not in ids_a

    def test_update_own_store(self, lojista_a):
        if "store_id" not in lojista_a:
            self.test_create_store_authenticated(lojista_a)
        sid = lojista_a["store_id"]
        r = lojista_a["session"].put(f"{API}/stores/{sid}",
                                     json={"name": "TEST_Store_A1_UPDATED"},
                                     timeout=15)
        assert r.status_code == 200, r.text
        # Verify persistence
        rget = requests.get(f"{API}/stores/{sid}", timeout=15)
        assert rget.status_code == 200
        assert rget.json()["name"] == "TEST_Store_A1_UPDATED"

    def test_update_other_lojistas_store_returns_403(self, lojista_a, lojista_b):
        if "store_id" not in lojista_b:
            rb = lojista_b["session"].post(f"{API}/stores", json={"name": "TEST_Store_B1", "whatsapp": "+552"}, timeout=15)
            lojista_b["store_id"] = rb.json()["id"]
        r = lojista_a["session"].put(f"{API}/stores/{lojista_b['store_id']}",
                                     json={"name": "HACKED"},
                                     timeout=15)
        assert r.status_code == 403, r.text

    def test_delete_own_store(self, lojista_a):
        # Create a fresh store to delete
        rc = lojista_a["session"].post(f"{API}/stores",
                                       json={"name": "TEST_Store_ToDelete", "whatsapp": "+55111"},
                                       timeout=15)
        assert rc.status_code == 200
        sid = rc.json()["id"]
        rd = lojista_a["session"].delete(f"{API}/stores/{sid}", timeout=15)
        assert rd.status_code == 200, rd.text
        # Verify gone
        rget = requests.get(f"{API}/stores/{sid}", timeout=15)
        assert rget.status_code == 404


# ---------- Products Tests ----------

class TestProducts:
    def test_create_product_for_own_store(self, lojista_a):
        if "store_id" not in lojista_a:
            rc = lojista_a["session"].post(f"{API}/stores",
                                           json={"name": "TEST_Store_ForProd", "whatsapp": "+55"},
                                           timeout=15)
            lojista_a["store_id"] = rc.json()["id"]
        r = lojista_a["session"].post(f"{API}/products",
                                      json={"store_id": lojista_a["store_id"],
                                            "name": "TEST_Prod_1",
                                            "description": "Delicioso",
                                            "price": 29.90,
                                            "category": "Lanche"},
                                      timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["name"] == "TEST_Prod_1"
        assert data["price"] == 29.90
        assert "id" in data
        lojista_a["product_id"] = data["id"]

    def test_create_product_for_other_store_returns_403(self, lojista_a, lojista_b):
        # A tries to create a product in B's store
        if "store_id" not in lojista_b:
            rb = lojista_b["session"].post(f"{API}/stores", json={"name": "TEST_Store_B_prod", "whatsapp": "+55"}, timeout=15)
            lojista_b["store_id"] = rb.json()["id"]
        r = lojista_a["session"].post(f"{API}/products",
                                      json={"store_id": lojista_b["store_id"],
                                            "name": "Malicious",
                                            "description": "x",
                                            "price": 1.0,
                                            "category": "x"},
                                      timeout=15)
        assert r.status_code == 403, r.text

    def test_list_products_by_store(self, lojista_a):
        if "product_id" not in lojista_a:
            self.test_create_product_for_own_store(lojista_a)
        r = requests.get(f"{API}/products/store/{lojista_a['store_id']}", timeout=15)
        assert r.status_code == 200, r.text
        products = r.json()
        assert isinstance(products, list)
        assert any(p["id"] == lojista_a["product_id"] for p in products)
        assert all("_id" not in p for p in products)

    def test_update_own_product(self, lojista_a):
        if "product_id" not in lojista_a:
            self.test_create_product_for_own_store(lojista_a)
        pid = lojista_a["product_id"]
        r = lojista_a["session"].put(f"{API}/products/{pid}",
                                     json={"price": 39.90, "name": "TEST_Prod_1_UPD"},
                                     timeout=15)
        assert r.status_code == 200, r.text
        # Verify via list
        rl = requests.get(f"{API}/products/store/{lojista_a['store_id']}", timeout=15)
        updated = next(p for p in rl.json() if p["id"] == pid)
        assert updated["price"] == 39.90
        assert updated["name"] == "TEST_Prod_1_UPD"

    def test_update_other_lojistas_product_returns_403(self, lojista_a, lojista_b):
        # B creates a product
        if "store_id" not in lojista_b:
            rb = lojista_b["session"].post(f"{API}/stores", json={"name": "TEST_S_B", "whatsapp": "+55"}, timeout=15)
            lojista_b["store_id"] = rb.json()["id"]
        rp = lojista_b["session"].post(f"{API}/products",
                                       json={"store_id": lojista_b["store_id"],
                                             "name": "TEST_B_Prod", "description": "x",
                                             "price": 10, "category": "cat"},
                                       timeout=15)
        assert rp.status_code == 200
        b_prod_id = rp.json()["id"]
        # A tries to update
        r = lojista_a["session"].put(f"{API}/products/{b_prod_id}", json={"name": "hack"}, timeout=15)
        assert r.status_code == 403, r.text

    def test_delete_own_product(self, lojista_a):
        # Create a fresh product to delete
        rp = lojista_a["session"].post(f"{API}/products",
                                       json={"store_id": lojista_a["store_id"],
                                             "name": "TEST_ProdDel", "description": "x",
                                             "price": 5, "category": "cat"},
                                       timeout=15)
        assert rp.status_code == 200
        pid = rp.json()["id"]
        rd = lojista_a["session"].delete(f"{API}/products/{pid}", timeout=15)
        assert rd.status_code == 200, rd.text


# ---------- Admin Tests ----------

class TestAdmin:
    def test_admin_can_list_all_stores(self, admin_session):
        r = admin_session.get(f"{API}/admin/stores", timeout=15)
        assert r.status_code == 200, r.text
        assert isinstance(r.json(), list)

    def test_admin_can_list_all_products(self, admin_session):
        r = admin_session.get(f"{API}/admin/products", timeout=15)
        assert r.status_code == 200, r.text
        assert isinstance(r.json(), list)

    def test_lojista_cannot_access_admin_stores(self, lojista_a):
        r = lojista_a["session"].get(f"{API}/admin/stores", timeout=15)
        assert r.status_code == 403, r.text

    def test_lojista_cannot_access_admin_products(self, lojista_a):
        r = lojista_a["session"].get(f"{API}/admin/products", timeout=15)
        assert r.status_code == 403, r.text

    def test_admin_can_delete_any_store(self, admin_session, lojista_b):
        # Create a store as lojista B
        rb = lojista_b["session"].post(f"{API}/stores",
                                       json={"name": "TEST_Store_ForAdminDel", "whatsapp": "+55"},
                                       timeout=15)
        assert rb.status_code == 200
        sid = rb.json()["id"]
        rd = admin_session.delete(f"{API}/stores/{sid}", timeout=15)
        assert rd.status_code == 200, rd.text
        # Confirm deleted
        rget = requests.get(f"{API}/stores/{sid}", timeout=15)
        assert rget.status_code == 404

    def test_admin_can_delete_any_product(self, admin_session, lojista_b):
        # Ensure B has a store & product
        if "store_id" not in lojista_b:
            rb = lojista_b["session"].post(f"{API}/stores", json={"name": "TEST_S_B_AdmDel", "whatsapp": "+55"}, timeout=15)
            lojista_b["store_id"] = rb.json()["id"]
        rp = lojista_b["session"].post(f"{API}/products",
                                       json={"store_id": lojista_b["store_id"],
                                             "name": "TEST_ProdAdmDel", "description": "x",
                                             "price": 1, "category": "x"},
                                       timeout=15)
        assert rp.status_code == 200
        pid = rp.json()["id"]
        rd = admin_session.delete(f"{API}/products/{pid}", timeout=15)
        assert rd.status_code == 200, rd.text


# ---------- Upload Tests ----------

class TestUpload:
    def test_upload_image_and_retrieve(self, lojista_a):
        # 1x1 PNG
        png = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
               b"\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc\xf8\xcf\xc0"
               b"\x00\x00\x00\x03\x00\x01\x5b\x8e\xe3\xd9\x00\x00\x00\x00IEND\xaeB`\x82")
        files = {"file": ("test.png", io.BytesIO(png), "image/png")}
        r = lojista_a["session"].post(f"{API}/upload", files=files, timeout=60)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "path" in data and data["path"]
        assert data["size"] > 0

        # Retrieve
        rget = requests.get(f"{API}/files/{data['path']}", timeout=60)
        assert rget.status_code == 200, rget.text
        assert rget.headers.get("content-type", "").startswith("image/")
        assert len(rget.content) > 0

    def test_upload_rejects_non_image(self, lojista_a):
        files = {"file": ("test.txt", io.BytesIO(b"hello"), "text/plain")}
        r = lojista_a["session"].post(f"{API}/upload", files=files, timeout=30)
        assert r.status_code == 400, r.text

    def test_upload_unauthenticated_returns_401(self):
        files = {"file": ("test.png", io.BytesIO(b"1234"), "image/png")}
        r = requests.post(f"{API}/upload", files=files, timeout=30)
        assert r.status_code == 401, r.text
