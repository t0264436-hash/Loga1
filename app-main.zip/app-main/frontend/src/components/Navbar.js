import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { ShoppingCart, User, LogOut, LayoutDashboard } from 'lucide-react';
import { Button } from './ui/button';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { cart } = useCart();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-xl bg-black/70 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center" data-testid="navbar-logo">
            <h1 className="text-2xl font-bold tracking-tight" style={{ fontFamily: 'Playfair Display' }}>
              <span className="text-[#F9F6EE]">C.</span>
              <span className="text-[#D4AF37]">G</span>
            </h1>
          </Link>

          <div className="flex items-center gap-4">
            {user && (
              <Link to="/dashboard">
                <Button variant="ghost" size="sm" className="text-[#F9F6EE] hover:text-[#D4AF37]" data-testid="navbar-dashboard-btn">
                  <LayoutDashboard className="w-4 h-4" />
                </Button>
              </Link>
            )}

            {cartItemCount > 0 && (
              <button className="relative text-[#F9F6EE] hover:text-[#D4AF37] transition-colors duration-200" data-testid="navbar-cart-btn">
                <ShoppingCart className="w-5 h-5" />
                <span className="absolute -top-2 -right-2 bg-[#D4AF37] text-[#0A0A0A] text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              </button>
            )}

            {user ? (
              <Button 
                onClick={handleLogout} 
                variant="ghost" 
                size="sm" 
                className="text-[#F9F6EE] hover:text-[#D4AF37]"
                data-testid="navbar-logout-btn"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            ) : (
              <Link to="/login">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-[#F9F6EE] hover:text-[#D4AF37]"
                  data-testid="navbar-login-btn"
                >
                  <User className="w-4 h-4" />
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
