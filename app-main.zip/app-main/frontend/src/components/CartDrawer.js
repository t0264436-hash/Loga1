import React from 'react';
import { X, Minus, Plus } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { toast } from 'sonner';

const CartDrawer = ({ open, onClose }) => {
  const { cart, currentStore, updateQuantity, removeFromCart, getTotal, clearCart } = useCart();
  const [paymentMethod, setPaymentMethod] = React.useState('pix');
  const [cashAmount, setCashAmount] = React.useState('');

  const handleCheckout = () => {
    if (!currentStore) return;

    const total = getTotal();
    let message = `*Pedido - ${currentStore.name}*\n\n`;
    
    cart.forEach(item => {
      message += `${item.quantity}x ${item.name} - R$ ${(item.price * item.quantity).toFixed(2)}\n`;
    });
    
    message += `\n*Total: R$ ${total.toFixed(2)}*\n\n`;
    message += `*Forma de Pagamento:* ${paymentMethod === 'pix' ? 'Pix' : paymentMethod === 'card' ? 'Cartão' : 'Dinheiro'}\n`;
    
    if (paymentMethod === 'cash' && cashAmount) {
      const change = parseFloat(cashAmount) - total;
      if (change >= 0) {
        message += `*Vai pagar com:* R$ ${parseFloat(cashAmount).toFixed(2)}\n`;
        message += `*Troco:* R$ ${change.toFixed(2)}\n`;
      }
    }

    const whatsappUrl = `https://wa.me/${currentStore.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    
    clearCart();
    onClose();
    toast.success('Pedido enviado para o WhatsApp!');
  };

  const total = getTotal();
  const change = paymentMethod === 'cash' && cashAmount ? Math.max(0, parseFloat(cashAmount) - total) : 0;

  if (cart.length === 0) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="bg-[#121212] border border-[#27272A] text-[#F9F6EE]">
          <DialogHeader>
            <DialogTitle className="text-2xl" style={{ fontFamily: 'Playfair Display' }}>Carrinho</DialogTitle>
          </DialogHeader>
          <div className="text-center py-8 text-[#A1A1AA]">
            Seu carrinho está vazio
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#121212] border border-[#27272A] text-[#F9F6EE] max-w-md max-h-[90vh] overflow-y-auto" data-testid="cart-drawer">
        <DialogHeader>
          <DialogTitle className="text-2xl tracking-tight" style={{ fontFamily: 'Playfair Display' }}>Carrinho</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {cart.map(item => (
            <div key={item.id} className="flex items-center gap-4 p-3 bg-[#1A1A1A] rounded-md border border-[#27272A]" data-testid={`cart-item-${item.id}`}>
              <div className="flex-1">
                <h4 className="font-medium text-sm">{item.name}</h4>
                <p className="text-[#D4AF37] text-sm font-medium">R$ {item.price.toFixed(2)}</p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  className="h-7 w-7 p-0 text-[#F9F6EE] hover:text-[#D4AF37]"
                  data-testid={`decrease-quantity-${item.id}`}
                >
                  <Minus className="w-3 h-3" />
                </Button>
                <span className="w-8 text-center" data-testid={`quantity-${item.id}`}>{item.quantity}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  className="h-7 w-7 p-0 text-[#F9F6EE] hover:text-[#D4AF37]"
                  data-testid={`increase-quantity-${item.id}`}
                >
                  <Plus className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => removeFromCart(item.id)}
                  className="h-7 w-7 p-0 text-red-400 hover:text-red-300 ml-2"
                  data-testid={`remove-item-${item.id}`}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-[#27272A] pt-4 mt-4">
          <div className="flex justify-between mb-4">
            <span className="font-medium">Total</span>
            <span className="text-[#D4AF37] font-bold text-xl" data-testid="cart-total">R$ {total.toFixed(2)}</span>
          </div>

          <div className="space-y-4">
            <Label className="text-sm uppercase tracking-[0.2em] text-[#D4AF37]">Forma de Pagamento</Label>
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} data-testid="payment-method-group">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="pix" id="pix" data-testid="payment-pix" />
                <Label htmlFor="pix" className="cursor-pointer">Pix</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="card" id="card" data-testid="payment-card" />
                <Label htmlFor="card" className="cursor-pointer">Cartão</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="cash" id="cash" data-testid="payment-cash" />
                <Label htmlFor="cash" className="cursor-pointer">Dinheiro</Label>
              </div>
            </RadioGroup>

            {paymentMethod === 'cash' && (
              <div className="space-y-2">
                <Label htmlFor="cash-amount">Vai pagar com quanto?</Label>
                <Input
                  id="cash-amount"
                  type="number"
                  step="0.01"
                  value={cashAmount}
                  onChange={(e) => setCashAmount(e.target.value)}
                  placeholder="R$ 0,00"
                  className="bg-[#121212] border-[#27272A] focus:border-[#D4AF37]"
                  data-testid="cash-amount-input"
                />
                {cashAmount && change >= 0 && (
                  <p className="text-sm text-[#A1A1AA]" data-testid="change-amount">
                    Troco: <span className="text-[#D4AF37] font-medium">R$ {change.toFixed(2)}</span>
                  </p>
                )}
                {cashAmount && parseFloat(cashAmount) < total && (
                  <p className="text-sm text-red-400">Valor insuficiente</p>
                )}
              </div>
            )}
          </div>

          <Button
            onClick={handleCheckout}
            disabled={paymentMethod === 'cash' && (!cashAmount || parseFloat(cashAmount) < total)}
            className="w-full mt-6 bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium"
            data-testid="checkout-btn"
          >
            Finalizar no WhatsApp
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CartDrawer;
