import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, user } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (user) navigate('/dashboard');
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = await login(email, password);
    
    if (result.success) {
      toast.success('Login realizado com sucesso!');
      navigate('/dashboard');
    } else {
      toast.error(result.error || 'Erro ao fazer login');
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 
            className="text-4xl sm:text-5xl tracking-tight mb-2" 
            style={{ fontFamily: 'Playfair Display' }}
            data-testid="login-title"
          >
            <span className="text-[#F9F6EE]">C.</span>
            <span className="text-[#D4AF37]">G</span>
          </h1>
          <p className="text-[#A1A1AA] text-sm">Faça login para gerenciar suas lojas</p>
        </div>

        <div className="bg-[#121212] border border-[#27272A] rounded-md p-8">
          <form onSubmit={handleSubmit} className="space-y-6" data-testid="login-form">
            <div>
              <Label htmlFor="email" className="text-[#F9F6EE]">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] text-[#F9F6EE] mt-2"
                data-testid="login-email-input"
              />
            </div>

            <div>
              <Label htmlFor="password" className="text-[#F9F6EE]">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] text-[#F9F6EE] mt-2"
                data-testid="login-password-input"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium"
              data-testid="login-submit-btn"
            >
              {loading ? 'Entrando...' : 'Entrar'}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-[#A1A1AA]">
              Não tem uma conta?{' '}
              <Link to="/register" className="text-[#D4AF37] hover:text-[#F3E5AB] transition-colors" data-testid="register-link">
                Cadastre-se
              </Link>
            </p>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link to="/" className="text-sm text-[#A1A1AA] hover:text-[#D4AF37] transition-colors" data-testid="back-home-link">
            Voltar para home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
