import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Plus, Edit, Trash2, ArrowLeft, Upload, Package } from 'lucide-react';
import { toast } from 'sonner';

const API = process.env.REACT_APP_BACKEND_URL;

const StoreManagement = () => {
  const { storeId } = useParams();
  const navigate = useNavigate();
  const [store, setStore] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '', description: '', price: '', category: '', image_path: ''
  });
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    fetchData();
  }, [storeId]);

  const fetchData = async () => {
    try {
      const [storeRes, productsRes] = await Promise.all([
        axios.get(`${API}/api/stores/${storeId}`),
        axios.get(`${API}/api/products/store/${storeId}`)
      ]);
      setStore(storeRes.data);
      setProducts(productsRes.data);
    } catch (error) {
      toast.error('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (file) => {
    setUploading(true);
    const uploadData = new FormData();
    uploadData.append('file', file);
    
    try {
      const { data } = await axios.post(`${API}/api/upload`, uploadData, {
        withCredentials: true,
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setFormData(prev => ({ ...prev, image_path: data.path }));
      toast.success('Imagem enviada!');
    } catch (error) {
      toast.error('Erro ao enviar imagem');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const productData = {
        ...formData,
        price: parseFloat(formData.price),
        store_id: storeId
      };
      
      if (editingProduct) {
        await axios.put(`${API}/api/products/${editingProduct.id || editingProduct._id}`, productData, { withCredentials: true });
        toast.success('Produto atualizado!');
      } else {
        await axios.post(`${API}/api/products`, productData, { withCredentials: true });
        toast.success('Produto criado!');
      }
      setDialogOpen(false);
      setEditingProduct(null);
      setFormData({ name: '', description: '', price: '', category: '', image_path: '' });
      fetchData();
    } catch (error) {
      toast.error('Erro ao salvar produto');
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price.toString(),
      category: product.category,
      image_path: product.image_path || ''
    });
    setDialogOpen(true);
  };

  const handleDelete = async (productId) => {
    if (!window.confirm('Deletar este produto?')) return;
    try {
      await axios.delete(`${API}/api/products/${productId}`, { withCredentials: true });
      toast.success('Produto deletado!');
      fetchData();
    } catch (error) {
      toast.error('Erro ao deletar');
    }
  };

  const openNewDialog = () => {
    setEditingProduct(null);
    setFormData({ name: '', description: '', price: '', category: '', image_path: '' });
    setDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A]">
        <Navbar />
        <div className="text-center py-20 text-[#A1A1AA]">Carregando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link to="/dashboard" className="inline-flex items-center gap-2 text-[#A1A1AA] hover:text-[#D4AF37] mb-6 transition-colors" data-testid="back-to-dashboard">
          <ArrowLeft className="w-4 h-4" />
          Voltar ao Dashboard
        </Link>

        <div className="flex flex-col sm:flex-row justify-between sm:items-start mb-12 gap-4">
          <div>
            <p className="text-xs tracking-[0.2em] uppercase text-[#D4AF37] mb-2">Produtos</p>
            <h1 
              className="text-4xl sm:text-5xl tracking-tight" 
              style={{ fontFamily: 'Playfair Display' }}
              data-testid="store-management-title"
            >
              {store?.name}
            </h1>
            <p className="text-[#A1A1AA] mt-2">Gerencie o cardápio</p>
          </div>
          <Button 
            onClick={openNewDialog}
            className="bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium"
            data-testid="new-product-btn"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Produto
          </Button>
        </div>

        {products.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 text-[#27272A] mx-auto mb-4" />
            <p className="text-[#A1A1AA] mb-6">Nenhum produto cadastrado</p>
            <Button 
              onClick={openNewDialog}
              className="bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium"
              data-testid="empty-new-product-btn"
            >
              <Plus className="w-4 h-4 mr-2" />
              Criar Primeiro Produto
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="products-grid">
            {products.map(product => {
              const productId = product.id || product._id;
              return (
                <div 
                  key={productId}
                  className="bg-[#121212] border border-[#27272A] rounded-md overflow-hidden"
                  data-testid={`product-card-${productId}`}
                >
                  {product.image_path ? (
                    <img 
                      src={`${API}/api/files/${product.image_path}`}
                      alt={product.name}
                      className="w-full h-40 object-cover"
                    />
                  ) : (
                    <div className="w-full h-40 bg-gradient-to-br from-[#121212] to-[#1A1A1A] flex items-center justify-center">
                      <Package className="w-12 h-12 text-[#D4AF37] opacity-30" />
                    </div>
                  )}
                  <div className="p-4">
                    <span className="text-xs tracking-[0.2em] uppercase text-[#D4AF37]">{product.category}</span>
                    <h3 className="text-lg tracking-tight mt-1" style={{ fontFamily: 'Playfair Display' }}>{product.name}</h3>
                    <p className="text-sm text-[#A1A1AA] mt-1 line-clamp-2">{product.description}</p>
                    <p className="text-[#D4AF37] font-bold text-xl mt-2">R$ {product.price.toFixed(2)}</p>
                    
                    <div className="grid grid-cols-2 gap-2 mt-4">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => handleEdit(product)}
                        className="w-full border-[#27272A] hover:border-[#D4AF37] text-[#F9F6EE]"
                        data-testid={`edit-product-${productId}`}
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Editar
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => handleDelete(productId)}
                        className="w-full border-[#27272A] hover:border-red-500 text-red-400"
                        data-testid={`delete-product-${productId}`}
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        Deletar
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-[#121212] border border-[#27272A] text-[#F9F6EE] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl tracking-tight" style={{ fontFamily: 'Playfair Display' }}>
              {editingProduct ? 'Editar Produto' : 'Novo Produto'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4" data-testid="product-form">
            <div>
              <Label>Nome do Produto</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] mt-2"
                data-testid="product-name-input"
              />
            </div>
            <div>
              <Label>Descrição</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                required
                className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] mt-2"
                data-testid="product-description-input"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Preço (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  required
                  className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] mt-2"
                  data-testid="product-price-input"
                />
              </div>
              <div>
                <Label>Categoria</Label>
                <Input
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  required
                  placeholder="Ex: Lanches"
                  className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] mt-2"
                  data-testid="product-category-input"
                />
              </div>
            </div>
            <div>
              <Label>Foto do Produto</Label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={(e) => e.target.files[0] && handleImageUpload(e.target.files[0])}
                className="hidden"
                data-testid="product-image-input"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="w-full mt-2 border-[#27272A] hover:border-[#D4AF37] text-[#F9F6EE]"
                data-testid="upload-product-image-btn"
              >
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? 'Enviando...' : formData.image_path ? 'Trocar imagem' : 'Enviar imagem'}
              </Button>
              {formData.image_path && (
                <div className="mt-2">
                  <img 
                    src={`${API}/api/files/${formData.image_path}`}
                    alt="Preview"
                    className="w-full h-32 object-cover rounded-md border border-[#27272A]"
                  />
                </div>
              )}
            </div>
            <Button 
              type="submit" 
              className="w-full bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium"
              data-testid="submit-product-btn"
            >
              {editingProduct ? 'Salvar Alterações' : 'Criar Produto'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default StoreManagement;
