import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';
import { Button } from '../components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Trash2, ArrowLeft, Store, Package, Shield } from 'lucide-react';
import { toast } from 'sonner';

const API = process.env.REACT_APP_BACKEND_URL;

const AdminPanel = () => {
  const [stores, setStores] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [storesRes, productsRes] = await Promise.all([
        axios.get(`${API}/api/admin/stores`, { withCredentials: true }),
        axios.get(`${API}/api/admin/products`, { withCredentials: true })
      ]);
      setStores(storesRes.data);
      setProducts(productsRes.data);
    } catch (error) {
      toast.error('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const deleteStore = async (storeId) => {
    if (!window.confirm('Deletar esta loja e todos os seus produtos?')) return;
    try {
      await axios.delete(`${API}/api/stores/${storeId}`, { withCredentials: true });
      toast.success('Loja deletada');
      fetchData();
    } catch (error) {
      toast.error('Erro ao deletar loja');
    }
  };

  const deleteProduct = async (productId) => {
    if (!window.confirm('Deletar este produto?')) return;
    try {
      await axios.delete(`${API}/api/products/${productId}`, { withCredentials: true });
      toast.success('Produto deletado');
      fetchData();
    } catch (error) {
      toast.error('Erro ao deletar produto');
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link to="/dashboard" className="inline-flex items-center gap-2 text-[#A1A1AA] hover:text-[#D4AF37] mb-6 transition-colors" data-testid="back-to-dashboard">
          <ArrowLeft className="w-4 h-4" />
          Voltar ao Dashboard
        </Link>

        <div className="mb-12">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-6 h-6 text-[#D4AF37]" />
            <p className="text-xs tracking-[0.2em] uppercase text-[#D4AF37]">Administração</p>
          </div>
          <h1 
            className="text-4xl sm:text-5xl tracking-tight" 
            style={{ fontFamily: 'Playfair Display' }}
            data-testid="admin-title"
          >
            Painel Admin
          </h1>
          <p className="text-[#A1A1AA] mt-2">Modere todas as lojas e produtos do marketplace</p>
        </div>

        {loading ? (
          <div className="text-center py-20 text-[#A1A1AA]">Carregando...</div>
        ) : (
          <Tabs defaultValue="stores" className="w-full">
            <TabsList className="bg-[#121212] border border-[#27272A]">
              <TabsTrigger value="stores" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-[#0A0A0A]" data-testid="tab-stores">
                <Store className="w-4 h-4 mr-2" />
                Lojas ({stores.length})
              </TabsTrigger>
              <TabsTrigger value="products" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-[#0A0A0A]" data-testid="tab-products">
                <Package className="w-4 h-4 mr-2" />
                Produtos ({products.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="stores" className="mt-6">
              {stores.length === 0 ? (
                <p className="text-[#A1A1AA] text-center py-12">Nenhuma loja cadastrada</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="admin-stores-grid">
                  {stores.map(store => {
                    const storeId = store.id || store._id;
                    return (
                      <div 
                        key={storeId}
                        className="bg-[#121212] border border-[#27272A] rounded-md overflow-hidden"
                        data-testid={`admin-store-${storeId}`}
                      >
                        {store.profile_image_path ? (
                          <img 
                            src={`${API}/api/files/${store.profile_image_path}`}
                            alt={store.name}
                            className="w-full h-32 object-cover"
                          />
                        ) : (
                          <div className="w-full h-32 bg-gradient-to-br from-[#121212] to-[#1A1A1A] flex items-center justify-center">
                            <Store className="w-8 h-8 text-[#D4AF37] opacity-30" />
                          </div>
                        )}
                        <div className="p-4">
                          <h3 className="text-lg tracking-tight" style={{ fontFamily: 'Playfair Display' }}>{store.name}</h3>
                          <p className="text-xs text-[#A1A1AA] mt-1">WhatsApp: {store.whatsapp}</p>
                          <p className="text-xs text-[#A1A1AA] mt-1 truncate">Owner: {store.owner_user_id}</p>
                          
                          <div className="flex gap-2 mt-4">
                            <Link to={`/store/${storeId}`} className="flex-1">
                              <Button size="sm" variant="outline" className="w-full border-[#27272A] hover:border-[#D4AF37] text-[#F9F6EE]" data-testid={`admin-view-store-${storeId}`}>
                                Ver
                              </Button>
                            </Link>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => deleteStore(storeId)}
                              className="flex-1 border-[#27272A] hover:border-red-500 text-red-400"
                              data-testid={`admin-delete-store-${storeId}`}
                            >
                              <Trash2 className="w-3 h-3 mr-1" />
                              Deletar
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            <TabsContent value="products" className="mt-6">
              {products.length === 0 ? (
                <p className="text-[#A1A1AA] text-center py-12">Nenhum produto cadastrado</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="admin-products-grid">
                  {products.map(product => {
                    const productId = product.id || product._id;
                    return (
                      <div 
                        key={productId}
                        className="bg-[#121212] border border-[#27272A] rounded-md overflow-hidden"
                        data-testid={`admin-product-${productId}`}
                      >
                        {product.image_path ? (
                          <img 
                            src={`${API}/api/files/${product.image_path}`}
                            alt={product.name}
                            className="w-full h-32 object-cover"
                          />
                        ) : (
                          <div className="w-full h-32 bg-gradient-to-br from-[#121212] to-[#1A1A1A] flex items-center justify-center">
                            <Package className="w-8 h-8 text-[#D4AF37] opacity-30" />
                          </div>
                        )}
                        <div className="p-4">
                          <span className="text-xs tracking-[0.2em] uppercase text-[#D4AF37]">{product.category}</span>
                          <h3 className="text-lg tracking-tight mt-1" style={{ fontFamily: 'Playfair Display' }}>{product.name}</h3>
                          <p className="text-[#D4AF37] font-bold mt-1">R$ {product.price.toFixed(2)}</p>
                          <p className="text-xs text-[#A1A1AA] mt-1 line-clamp-2">{product.description}</p>
                          
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => deleteProduct(productId)}
                            className="w-full mt-4 border-[#27272A] hover:border-red-500 text-red-400"
                            data-testid={`admin-delete-product-${productId}`}
                          >
                            <Trash2 className="w-3 h-3 mr-1" />
                            Deletar
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;
