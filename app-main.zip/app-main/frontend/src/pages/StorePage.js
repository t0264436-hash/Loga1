import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';
import CartDrawer from '../components/CartDrawer';
import { Button } from '../components/ui/button';
import { Store, Plus, ShoppingCart, Package, ArrowLeft } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';

const API = process.env.REACT_APP_BACKEND_URL;

const StorePage = () => {
  const { storeId } = useParams();
  const [store, setStore] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cartOpen, setCartOpen] = useState(false);
  const { cart, addToCart } = useCart();

  useEffect(() => {
    fetchData();
  }, [storeId]);

  const fetchData = async () => {
    try {
      const [storeRes, productsRes] = await Promise.all([
        axios.get(`${API}/api/stores/${storeId}`),
        axios.get(`${API}/api/products/store/${storeId}`)
      ]);
      setStore(storeRes.data);
      setProducts(productsRes.data);
    } catch (error) {
      toast.error('Loja não encontrada');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = (product) => {
    const added = addToCart({ ...product, id: product.id || product._id }, { ...store, id: storeId });
    if (added) {
      toast.success(`${product.name} adicionado ao carrinho!`);
    }
  };

  const productsByCategory = products.reduce((acc, product) => {
    if (!acc[product.category]) acc[product.category] = [];
    acc[product.category].push(product);
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A]">
        <Navbar />
        <div className="text-center py-20 text-[#A1A1AA]">Carregando...</div>
      </div>
    );
  }

  if (!store) {
    return (
      <div className="min-h-screen bg-[#0A0A0A]">
        <Navbar />
        <div className="text-center py-20">
          <p className="text-[#A1A1AA]">Loja não encontrada</p>
          <Link to="/">
            <Button className="mt-4 bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB]" data-testid="back-home-btn">Voltar</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <Navbar />
      
      <div className="relative">
        <div className="h-64 sm:h-80 overflow-hidden relative">
          {store.profile_image_path ? (
            <img 
              src={`${API}/api/files/${store.profile_image_path}`}
              alt={store.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-[#121212] to-[#1A1A1A] flex items-center justify-center">
              <Store className="w-20 h-20 text-[#D4AF37] opacity-30" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/40 to-transparent"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-24 relative z-10">
          <Link to="/" className="inline-flex items-center gap-2 text-[#F9F6EE] hover:text-[#D4AF37] mb-6 transition-colors" data-testid="back-to-home">
            <ArrowLeft className="w-4 h-4" />
            Cardápio Geral
          </Link>

          <div className="bg-[#121212] border border-[#27272A] rounded-md p-8 mb-8">
            <p className="text-xs tracking-[0.2em] uppercase text-[#D4AF37] mb-2">Cardápio</p>
            <h1 
              className="text-4xl sm:text-5xl lg:text-6xl tracking-tight leading-none" 
              style={{ fontFamily: 'Playfair Display' }}
              data-testid="store-name"
            >
              {store.name}
            </h1>
            <p className="text-[#A1A1AA] mt-3 text-sm">WhatsApp: {store.whatsapp}</p>
          </div>

          {products.length === 0 ? (
            <div className="text-center py-20">
              <Package className="w-16 h-16 text-[#27272A] mx-auto mb-4" />
              <p className="text-[#A1A1AA]">Nenhum produto disponível ainda</p>
            </div>
          ) : (
            <div className="space-y-12 pb-24">
              {Object.entries(productsByCategory).map(([category, items]) => (
                <div key={category} data-testid={`category-${category}`}>
                  <h2 
                    className="text-2xl sm:text-3xl lg:text-4xl tracking-tight mb-6 border-b border-[#27272A] pb-3" 
                    style={{ fontFamily: 'Playfair Display' }}
                  >
                    {category}
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {items.map(product => {
                      const productId = product.id || product._id;
                      return (
                        <div 
                          key={productId}
                          className="bg-[#121212] border border-[#27272A] rounded-md overflow-hidden card-hover"
                          data-testid={`store-product-${productId}`}
                        >
                          {product.image_path ? (
                            <img 
                              src={`${API}/api/files/${product.image_path}`}
                              alt={product.name}
                              className="w-full h-48 object-cover"
                            />
                          ) : (
                            <div className="w-full h-48 bg-gradient-to-br from-[#121212] to-[#1A1A1A] flex items-center justify-center">
                              <Package className="w-12 h-12 text-[#D4AF37] opacity-30" />
                            </div>
                          )}
                          <div className="p-5">
                            <h3 className="text-lg tracking-tight" style={{ fontFamily: 'Playfair Display' }}>{product.name}</h3>
                            <p className="text-sm text-[#A1A1AA] mt-1 line-clamp-2 min-h-[2.5rem]">{product.description}</p>
                            <div className="flex items-center justify-between mt-4">
                              <p className="text-[#D4AF37] font-bold text-xl">R$ {product.price.toFixed(2)}</p>
                              <Button
                                size="sm"
                                onClick={() => handleAddToCart(product)}
                                className="bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium"
                                data-testid={`add-to-cart-${productId}`}
                              >
                                <Plus className="w-4 h-4 mr-1" />
                                Adicionar
                              </Button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {cart.length > 0 && (
        <button
          onClick={() => setCartOpen(true)}
          className="fixed bottom-6 right-6 bg-[#D4AF37] text-[#0A0A0A] px-6 py-3 rounded-md font-medium shadow-lg hover:bg-[#F3E5AB] transition-colors duration-200 flex items-center gap-2"
          data-testid="floating-cart-btn"
        >
          <ShoppingCart className="w-4 h-4" />
          Ver Carrinho ({cart.reduce((sum, item) => sum + item.quantity, 0)})
        </button>
      )}

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </div>
  );
};

export default StorePage;
