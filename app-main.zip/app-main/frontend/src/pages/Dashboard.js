import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Plus, Store, Edit, Trash2, Package } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '../contexts/AuthContext';

const API = process.env.REACT_APP_BACKEND_URL;

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingStore, setEditingStore] = useState(null);
  const [formData, setFormData] = useState({ name: '', whatsapp: '', profile_image_path: null });
  const [imageFile, setImageFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => { fetchMyStores(); }, []);

  const fetchMyStores = async () => {
    try {
      const { data } = await axios.get(`${API}/api/stores/my`, { withCredentials: true });
      setStores(data);
    } catch (error) {
      toast.error('Erro ao carregar lojas');
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (file) => {
    const formDataUpload = new FormData();
    formDataUpload.append('file', file);
    const { data } = await axios.post(`${API}/api/upload`, formDataUpload, {
      withCredentials: true,
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    return data.path;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUploading(true);
    try {
      let imagePath = formData.profile_image_path;
      if (imageFile) imagePath = await handleImageUpload(imageFile);
      const payload = { ...formData, profile_image_path: imagePath };
      if (editingStore) {
        await axios.put(`${API}/api/stores/${editingStore.id || editingStore._id}`, payload, { withCredentials: true });
        toast.success('Loja atualizada!');
      } else {
        await axios.post(`${API}/api/stores`, payload, { withCredentials: true });
        toast.success('Loja criada!');
      }
      resetForm();
      fetchMyStores();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao salvar loja');
    } finally {
      setUploading(false);
    }
  };

  const handleEdit = (store) => {
    setEditingStore(store);
    setFormData({ name: store.name, whatsapp: store.whatsapp, profile_image_path: store.profile_image_path });
    setDialogOpen(true);
  };

  const handleDelete = async (storeId) => {
    if (!window.confirm('Tem certeza que deseja excluir esta loja e todos seus produtos?')) return;
    try {
      await axios.delete(`${API}/api/stores/${storeId}`, { withCredentials: true });
      toast.success('Loja excluída');
      fetchMyStores();
    } catch (error) {
      toast.error('Erro ao excluir loja');
    }
  };

  const resetForm = () => {
    setFormData({ name: '', whatsapp: '', profile_image_path: null });
    setImageFile(null);
    setEditingStore(null);
    setDialogOpen(false);
  };

  const copyStoreLink = (storeId) => {
    const url = `${window.location.origin}/store/${storeId}`;
    navigator.clipboard.writeText(url);
    toast.success('Link copiado!');
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
          <div>
            <p className="text-xs tracking-[0.2em] uppercase text-[#D4AF37] mb-2">Painel do Lojista</p>
            <h1 className="text-3xl sm:text-4xl tracking-tight" style={{ fontFamily: 'Playfair Display' }} data-testid="dashboard-title">Minhas Lojas</h1>
            <p className="text-sm text-[#A1A1AA] mt-1">Olá, {user?.name}</p>
          </div>
          <div className="flex gap-3">
            {user?.role === 'admin' && (
              <Button onClick={() => navigate('/admin')} variant="outline" className="border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0A0A0A]" data-testid="admin-panel-btn">Painel Admin</Button>
            )}
            <Dialog open={dialogOpen} onOpenChange={(open) => { if (!open) resetForm(); else setDialogOpen(true); }}>
              <DialogTrigger asChild>
                <Button className="bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium" data-testid="new-store-btn">
                  <Plus className="w-4 h-4 mr-2" />Nova Loja
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#121212] border border-[#27272A] text-[#F9F6EE]">
                <DialogHeader>
                  <DialogTitle style={{ fontFamily: 'Playfair Display' }} className="text-2xl">{editingStore ? 'Editar Loja' : 'Nova Loja'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4" data-testid="store-form">
                  <div>
                    <Label>Nome da Loja</Label>
                    <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} required className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] mt-2" data-testid="store-name-input" />
                  </div>
                  <div>
                    <Label>WhatsApp (com DDI e DDD)</Label>
                    <Input value={formData.whatsapp} onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })} placeholder="5511999999999" required className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] mt-2" data-testid="store-whatsapp-input" />
                    <p className="text-xs text-[#A1A1AA] mt-1">Formato: 55 + DDD + número (ex: 5511999999999)</p>
                  </div>
                  <div>
                    <Label>Foto de Perfil</Label>
                    <Input type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files[0])} className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] mt-2" data-testid="store-image-input" />
                  </div>
                  <Button type="submit" disabled={uploading} className="w-full bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium" data-testid="save-store-btn">
                    {uploading ? 'Salvando...' : editingStore ? 'Atualizar' : 'Criar Loja'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-20 text-[#D4AF37]">Carregando...</div>
        ) : stores.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-[#27272A] rounded-md">
            <Store className="w-16 h-16 text-[#27272A] mx-auto mb-4" />
            <p className="text-[#A1A1AA] mb-4">Você ainda não tem lojas cadastradas</p>
            <Button onClick={() => setDialogOpen(true)} className="bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium" data-testid="empty-create-store-btn">Criar primeira loja</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {stores.map(store => (
              <div key={store.id || store._id} className="bg-[#121212] border border-[#27272A] rounded-md overflow-hidden card-hover" data-testid={`my-store-card-${store.id || store._id}`}>
                {store.profile_image_path ? (
                  <img src={`${API}/api/files/${store.profile_image_path}`} alt={store.name} className="w-full h-40 object-cover" />
                ) : (
                  <div className="w-full h-40 bg-gradient-to-br from-[#121212] to-[#1A1A1A] flex items-center justify-center">
                    <Store className="w-12 h-12 text-[#D4AF37] opacity-30" />
                  </div>
                )}
                <div className="p-5">
                  <h3 className="text-xl tracking-tight mb-1" style={{ fontFamily: 'Playfair Display' }}>{store.name}</h3>
                  <p className="text-xs text-[#A1A1AA] mb-4">{store.whatsapp}</p>
                  <div className="grid grid-cols-2 gap-2">
                    <Button size="sm" onClick={() => navigate(`/dashboard/store/${store.id || store._id}`)} className="bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium" data-testid={`manage-products-btn-${store.id || store._id}`}>
                      <Package className="w-3 h-3 mr-1" />Produtos
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => copyStoreLink(store.id || store._id)} className="border-[#27272A] text-[#F9F6EE] hover:border-[#D4AF37]" data-testid={`copy-link-btn-${store.id || store._id}`}>
                      Copiar Link
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleEdit(store)} className="border-[#27272A] text-[#F9F6EE] hover:border-[#D4AF37]" data-testid={`edit-store-btn-${store.id || store._id}`}>
                      <Edit className="w-3 h-3 mr-1" />Editar
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleDelete(store.id || store._id)} className="border-[#27272A] text-red-400 hover:border-red-400" data-testid={`delete-store-btn-${store.id || store._id}`}>
                      <Trash2 className="w-3 h-3 mr-1" />Excluir
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
