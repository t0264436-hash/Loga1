import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { register, user } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (user) navigate('/dashboard');
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = await register(email, password, name);
    
    if (result.success) {
      toast.success('Conta criada com sucesso!');
      navigate('/dashboard');
    } else {
      toast.error(result.error || 'Erro ao criar conta');
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 
            className="text-4xl sm:text-5xl tracking-tight mb-2" 
            style={{ fontFamily: 'Playfair Display' }}
            data-testid="register-title"
          >
            <span className="text-[#F9F6EE]">C.</span>
            <span className="text-[#D4AF37]">G</span>
          </h1>
          <p className="text-[#A1A1AA] text-sm">Crie sua conta e comece a vender</p>
        </div>

        <div className="bg-[#121212] border border-[#27272A] rounded-md p-8">
          <form onSubmit={handleSubmit} className="space-y-6" data-testid="register-form">
            <div>
              <Label htmlFor="name" className="text-[#F9F6EE]">Nome</Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] text-[#F9F6EE] mt-2"
                data-testid="register-name-input"
              />
            </div>

            <div>
              <Label htmlFor="email" className="text-[#F9F6EE]">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] text-[#F9F6EE] mt-2"
                data-testid="register-email-input"
              />
            </div>

            <div>
              <Label htmlFor="password" className="text-[#F9F6EE]">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="bg-[#0A0A0A] border-[#27272A] focus:border-[#D4AF37] text-[#F9F6EE] mt-2"
                data-testid="register-password-input"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[#D4AF37] text-[#0A0A0A] hover:bg-[#F3E5AB] font-medium"
              data-testid="register-submit-btn"
            >
              {loading ? 'Criando conta...' : 'Criar Conta'}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-[#A1A1AA]">
              Já tem uma conta?{' '}
              <Link to="/login" className="text-[#D4AF37] hover:text-[#F3E5AB] transition-colors" data-testid="login-link">
                Faça login
              </Link>
            </p>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link to="/" className="text-sm text-[#A1A1AA] hover:text-[#D4AF37] transition-colors" data-testid="back-home-link">
            Voltar para home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
