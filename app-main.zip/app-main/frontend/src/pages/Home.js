import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';
import { Store, MapPin } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import CartDrawer from '../components/CartDrawer';

const API = process.env.REACT_APP_BACKEND_URL;

const Home = () => {
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const { cart } = useCart();
  const [cartOpen, setCartOpen] = useState(false);

  useEffect(() => {
    fetchStores();
  }, []);

  const fetchStores = async () => {
    try {
      const { data } = await axios.get(`${API}/api/stores`);
      setStores(data);
    } catch (error) {
      console.error('Erro ao carregar lojas:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <Navbar />
      
      <div className="relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center mb-16">
            <h1 
              className="text-4xl sm:text-5xl lg:text-6xl tracking-tight leading-none mb-4" 
              style={{ fontFamily: 'Playfair Display' }}
              data-testid="home-title"
            >
              <span className="text-[#F9F6EE]">Cardápio </span>
              <span className="text-[#D4AF37]">Geral</span>
            </h1>
            <p className="text-base text-[#A1A1AA] max-w-2xl mx-auto">
              Descubra os melhores estabelecimentos da sua região
            </p>
          </div>

          {loading ? (
            <div className="flex justify-center py-20">
              <div className="text-[#D4AF37]">Carregando lojas...</div>
            </div>
          ) : stores.length === 0 ? (
            <div className="text-center py-20">
              <Store className="w-16 h-16 text-[#27272A] mx-auto mb-4" />
              <p className="text-[#A1A1AA]">Nenhuma loja cadastrada ainda</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="stores-grid">
              {stores.map(store => (
                <Link 
                  key={store.id || store._id} 
                  to={`/store/${store.id || store._id}`}
                  className="card-hover"
                  data-testid={`store-card-${store.id || store._id}`}
                >
                  <div className="bg-[#121212] border border-[#27272A] rounded-md overflow-hidden h-full">
                    {store.profile_image_path ? (
                      <img 
                        src={`${API}/api/files/${store.profile_image_path}`}
                        alt={store.name}
                        className="w-full h-48 object-cover"
                      />
                    ) : (
                      <div className="w-full h-48 bg-gradient-to-br from-[#121212] to-[#1A1A1A] flex items-center justify-center">
                        <Store className="w-16 h-16 text-[#D4AF37] opacity-30" />
                      </div>
                    )}
                    <div className="p-6">
                      <h3 
                        className="text-xl sm:text-2xl tracking-tight mb-2" 
                        style={{ fontFamily: 'Playfair Display' }}
                      >
                        {store.name}
                      </h3>
                      <p className="text-sm text-[#A1A1AA] flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        WhatsApp: {store.whatsapp}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>

      {cart.length > 0 && (
        <button
          onClick={() => setCartOpen(true)}
          className="fixed bottom-6 right-6 bg-[#D4AF37] text-[#0A0A0A] px-6 py-3 rounded-md font-medium shadow-lg hover:bg-[#F3E5AB] transition-colors duration-200"
          data-testid="floating-cart-btn"
        >
          Ver Carrinho ({cart.reduce((sum, item) => sum + item.quantity, 0)})
        </button>
      )}

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </div>
  );
};

export default Home;
