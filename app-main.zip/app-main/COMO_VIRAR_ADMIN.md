# Como virar Administrador do Site C.G

## Credenciais Atuais do Admin

Uma conta admin **já foi criada automaticamente** com base nas variáveis de ambiente do arquivo `/app/backend/.env`:

- **Email:** `admin@cg.com`
- **Senha:** `admin123`

## PASSO A PASSO PARA VIRAR ADMIN COM SEGURANÇA

### 1. Trocar as credenciais padrão (OBRIGATÓRIO em produção)

As credenciais atuais são valores de exemplo e **devem ser trocadas** antes do site ir para o público.

Abra o arquivo `/app/backend/.env` e altere:

```env
ADMIN_EMAIL="seuemailreal@gmail.com"
ADMIN_PASSWORD="UmaSenhaMuitoForteAqui#2026!"
JWT_SECRET="troque_isso_por_uma_string_aleatoria_de_64_caracteres"
```

**Dicas para uma senha forte:**
- Mínimo 12 caracteres
- Misture letras maiúsculas, minúsculas, números e símbolos
- NÃO use palavras do dicionário
- Exemplo: `Xk9!mQ2$vB7@nP3&`

**Para gerar um JWT_SECRET seguro**, execute no terminal:
```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

### 2. Reiniciar o backend para aplicar

```bash
sudo supervisorctl restart backend
```

O sistema irá:
- Se admin ainda **não existe** → criar novo admin com o email/senha do .env
- Se admin **já existe** com esse email → atualizar a senha automaticamente
- A senha é armazenada **criptografada com bcrypt** (nunca em texto plano)

### 3. Fazer login

1. Acesse `https://SEUSITE/login`
2. Use o email e senha configurados no `.env`
3. Você será redirecionado para `/dashboard`
4. Clique no botão **"Painel Admin"** (aparece só para admins) para acessar `/admin`

### 4. Poderes do Admin

No painel `/admin` você pode:
- Ver TODAS as lojas de TODOS os lojistas
- Ver TODOS os produtos de TODAS as lojas
- **Deletar qualquer loja** (com todos seus produtos em cascata)
- **Deletar qualquer produto** individual
- Visitar a página pública de qualquer loja para inspecionar

O admin também pode editar via API PUT `/api/stores/{id}` e `/api/products/{id}` (roles são validados no backend).

## PRINCÍPIOS DE SEGURANÇA APLICADOS

1. **Zero credenciais no código-fonte** — tudo vem de variáveis de ambiente
2. **Senhas com bcrypt** — nem o banco de dados vê a senha em texto
3. **JWT com expiração curta** — access token dura 15 minutos, refresh dura 7 dias
4. **Cookies HttpOnly** — impossível de roubar via JavaScript malicioso (XSS)
5. **Autorização em cada endpoint** — checagem de dono/admin no backend
6. **CORS restrito** — só o frontend oficial pode chamar o backend

## Como criar um SEGUNDO administrador (opcional)

O sistema atual seed apenas UM admin (o do .env). Se quiser um segundo admin:

1. A pessoa cria conta normal em `/register`
2. Você (admin atual) roda no MongoDB:
```javascript
db.users.updateOne(
  { email: "email_do_segundo_admin@email.com" },
  { $set: { role: "admin" } }
)
```

## ATENÇÃO

- Nunca compartilhe seu `.env` publicamente (nunca commit ele no git)
- O `JWT_SECRET` só pode ser trocado quando não houver usuários logados (invalida sessões)
- Faça backup do MongoDB periodicamente
